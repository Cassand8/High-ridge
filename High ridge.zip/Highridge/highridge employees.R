employees <- list()

# Loop for creating employee names
for (i in 1:500) {
  employee_name <- paste("employee", i, sep = "_")
  employees <- append(employees, employee_name) 
  
  print(employees)
  
  # Nested loop to assign salary and level
  for (employee in employees) {
    
    salary <- sample(5000:30000, 1)
    print(paste("payment slip for", employee, "- salary: $", salary, sep = " "))
    
    female_employees <- paste("employee", i, sep = "_")
    
    for (i in 1:(500 / 2)) {
      
      # Assign employee level based on salary
      if (salary > 10000 & salary < 20000) {
        employee_level <- "A1"
      }
      
      # Check if the employee is female and has a salary range
      if (employee == female_employees & salary > 7500 & salary < 30000) {
        employee_level <- "A5-F"
      }
      
      # Assign gender
      gender <- ifelse(employee == female_employees, "female", "male")
      
      print(paste("payment slip for", employee, "(", gender, ") - salary: $", salary, "- level: ", employee_level, sep = ""))
    }
  }
}

