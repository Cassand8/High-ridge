employees = []
for i in range(1, 501):
    employee_name = f"employee_{i}" # type: ignore
    employees.append(employee_name)  
    print(employees)
    for employee in employees:

        import random
        salary = random.randint (5000, 30000)
        print(f"payment slip for {employee} - salary: ${salary}")
        female_employees = f"employee_{i}" 
        for i in range (1, 501 // 2):
             if 10000 < salary <20000:     
                employee_level = "A1"
             if employee in female_employees and 7500 < salary < 30000:
                employee_level = "A5-F"
             gender = "female" if employee in female_employees else "male"
             print(f"payment slip for {employee} ({gender}) - salary: ${salary} - level: {employee_level}")
        except Exception as e:
             print(f"error processing{employee}: {e}") # type: ignore
    

